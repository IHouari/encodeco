import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/hash_utils.dart';

class AppLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked; // called when user enters correct password

  const AppLockScreen({super.key, required this.onUnlocked});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final TextEditingController _controller = TextEditingController();
  String? _storedHash;
  bool _isSettingNew = false;
  bool _obscure = true;
  int _failedAttempts = 0;
  bool _isLocked = false;

  @override
  void initState() {
    super.initState();
    _loadStoredHash();
  }

  Future<void> _loadStoredHash() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _storedHash = prefs.getString('master_password');
      _isSettingNew = _storedHash == null;
    });
  }

  Future<void> _handleSubmit() async {
    final prefs = await SharedPreferences.getInstance();
    final enteredHash = hashPassword(_controller.text.trim());

    if (_isSettingNew) {
      await prefs.setString('master_password', enteredHash);
      widget.onUnlocked();
    } else {
      if (_isLocked) return;
      if (enteredHash == _storedHash) {
        _failedAttempts = 0;
        widget.onUnlocked();
      } else {
        setState(() {
          _failedAttempts++;
        });
        if (_failedAttempts >= 3) {
          setState(() {
            _isLocked = true;
          });
          Future.delayed(const Duration(seconds: 15), () {
            setState(() {
              _isLocked = false;
              _failedAttempts = 0;
            });
          });
        }
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_isLocked
              ? 'Too many wrong attempts. Locked for 15s.'
              : 'Incorrect password. Try again.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                _isSettingNew ? 'Set Master Password' : 'Enter Master Password',
                style: const TextStyle(color: Colors.white, fontSize: 22),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _controller,
                obscureText: _obscure,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.grey[850],
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none),
                  suffixIcon: IconButton(
                    icon: Icon(
                        _obscure ? Icons.visibility : Icons.visibility_off,
                        color: Colors.white70),
                    onPressed: () {
                      setState(() {
                        _obscure = !_obscure;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isLocked ? null : _handleSubmit,
                child: Text(_isSettingNew ? 'Set Password' : 'Unlock'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
