import 'package:flutter/material.dart';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../main.dart'; // import Encryptor

class AppLockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const AppLockScreen({super.key, required this.onUnlocked});

  @override
  State<AppLockScreen> createState() => _AppLockScreenState();
}

class _AppLockScreenState extends State<AppLockScreen> {
  final TextEditingController _controller = TextEditingController();
  String? _storedPassword;
  bool _isSetting = false;
  String _message = '';

  @override
  void initState() {
    super.initState();
    _loadPassword();
  }

  Future<void> _loadPassword() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('master_password');
    setState(() {
      _storedPassword = saved;
      _isSetting = saved == null;
    });
  }

  Future<void> _savePassword(String password) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('master_password', password);
  }

  void _verifyPassword() async {
    final input = _controller.text;
    if (_isSetting) {
      if (input.isNotEmpty) {
        await _savePassword(input);
        widget.onUnlocked();
      } else {
        setState(() => _message = 'Please enter a valid password.');
      }
    } else {
      if (input == _storedPassword) {
        widget.onUnlocked();
      } else {
        setState(() => _message = 'Incorrect password.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                _isSetting ? 'Set Master Password' : 'Enter Master Password',
                style: const TextStyle(fontSize: 20, color: Colors.white),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _controller,
                obscureText: true,
                decoration: const InputDecoration(
                  filled: true,
                  fillColor: Colors.white12,
                  border: OutlineInputBorder(),
                  hintText: 'Password',
                ),
                style: const TextStyle(color: Colors.white),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: _verifyPassword,
                child: Text(_isSetting ? 'Set Password' : 'Unlock'),
              ),
              const SizedBox(height: 12),
              Text(_message, style: const TextStyle(color: Colors.redAccent)),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------- Main Encrypt/Decrypt UI ----------------------
class EncryptDecryptScreen extends StatefulWidget {
  const EncryptDecryptScreen({super.key});

  @override
  State<EncryptDecryptScreen> createState() => _EncryptDecryptScreenState();
}

class _EncryptDecryptScreenState extends State<EncryptDecryptScreen> {
  File? _inputFile;
  File? _outputFile;
  final TextEditingController _passController = TextEditingController();
  double _progress = 0;
  String _status = '';

  void _pickInputFile() async {
    final result = await FilePicker.platform.pickFiles();
    if (result != null && result.files.single.path != null) {
      setState(() => _inputFile = File(result.files.single.path!));
    }
  }

  void _pickOutputFile() async {
    final result = await FilePicker.platform.saveFile(
      dialogTitle: 'Select output file',
      fileName: _inputFile != null ? 'output.enc' : 'output.txt',
    );
    if (result != null) setState(() => _outputFile = File(result));
  }

  void _encryptFile() async {
    if (_inputFile == null || _outputFile == null || _passController.text.isEmpty) {
      setState(() => _status = 'Please select files and enter a passphrase.');
      return;
    }
    setState(() {
      _progress = 0;
      _status = 'Encrypting...';
    });
    try {
      await Encryptor.encryptFile(
        _inputFile!,
        _outputFile!,
        _passController.text,
        onProgress: (p) => setState(() => _progress = p),
      );
      setState(() => _status = 'Encryption completed!');
    } catch (e) {
      setState(() => _status = 'Error: $e');
    }
  }

  void _decryptFile() async {
    if (_inputFile == null || _outputFile == null || _passController.text.isEmpty) {
      setState(() => _status = 'Please select files and enter a passphrase.');
      return;
    }
    setState(() {
      _progress = 0;
      _status = 'Decrypting...';
    });
    try {
      await Encryptor.decryptFile(
        _inputFile!,
        _outputFile!,
        _passController.text,
        onProgress: (p) => setState(() => _progress = p),
      );
      setState(() => _status = 'Decryption completed!');
    } catch (e) {
      setState(() => _status = 'Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Encrypt / Decrypt')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: _passController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Passphrase'),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                        onPressed: _pickInputFile,
                        child: Text(_inputFile != null ? 'Input: ${_inputFile!.path.split('/').last}' : 'Select Input File')),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                        onPressed: _pickOutputFile,
                        child: Text(_outputFile != null ? 'Output: ${_outputFile!.path.split('/').last}' : 'Select Output File')),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(child: ElevatedButton(onPressed: _encryptFile, child: const Text('Encrypt'))),
                  const SizedBox(width: 10),
                  Expanded(child: ElevatedButton(onPressed: _decryptFile, child: const Text('Decrypt'))),
                ],
              ),
              const SizedBox(height: 16),
              LinearProgressIndicator(value: _progress),
              const SizedBox(height: 16),
              Text(_status),
            ],
          ),
        ),
      ),
    );
  }
}
